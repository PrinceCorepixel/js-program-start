/* create faulty  calculrtor

this faluty calculetor does following  : 
it takes tow number as input form the  user 
10% fo the time
+ = -
* = +
- = /
/ = **
*/

const obj = { };
console.log(obj.___proto__ === Object.prototype);