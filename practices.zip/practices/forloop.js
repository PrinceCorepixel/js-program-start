// let a = 1;
// for (let i = 0; i < 100; i++) {
//     console.log(i);
// }
// let obj = {
//     name: "prince",
//     role: "ui/ui",
//     compny: "corepixel"
// }
// for (const key in obj) {
//     const element = obj[key];
//     console.log(key)
// }
// for (const c of "prince") {
//     con
//     sole.log(c )
// } let
let i = 1;
// while (i <= 6) {
//     console.log(i)
//     i++;
// }
do {
    console.log(i)
    i++;
} while (i <= 6);