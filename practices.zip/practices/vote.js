let age = 17

if( age > 17){
    console.log("You can drive");
}
else {
    console.log("You can't drive");
}