let value = 3
let negValue = -value
console.log(typeof negValue);

let str1 = "prince"
let str2 = " hello"

let str3 = str1 + str2
console.log(str3);

console.log(2 + "1");
console.log("2" + 1);
console.log("1" + 2 + 3);
console.log(1 + "2" + 3);
console.log(1 + 2 + "3");

console.log(+false);