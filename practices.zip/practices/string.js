// let a = "prince"
// console.log(a[0])

// console.log(a.length)
let real_name = "prince"
let frinde = "rohan"

console.log("his name is  " + real_name + " his frinde name is " + frinde) 
console.log(`his name is ${real_name} and his frinde name if ${frinde}`)
console.log(real_name.slice(0,3))