// console.log(2 > 1);
// console.log(2 >= 6);
// console.log("2" > 1);
// console.log("1" > 1);
// console.log(null > 0);
console.log(null <= undefined);
console.log("55" === "55");
