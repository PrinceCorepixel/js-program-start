const bigNumber = 32335264154564654n

console.log(typeof bigNumber);
// 
const hero = ["prince", "raju", "raj", "gopal"];
let myObj = {
    name: "peinceTejani",
    aeg: 18,
}
// function
let  myFuction = function(){
    console.log("Prince Tejani M");
}
console.table(hero);   