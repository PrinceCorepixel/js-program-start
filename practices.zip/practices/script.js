// console.log(" hi i am prince tejani");
// let a = 3;
// let b = "prince";
// let c = 2.33;
// const x = true;
// let y = undefined;
// let z = null;
// console.log(a, b, c, x, y, z);
// console.log(typeof a, typeof b, typeof c, typeof x, typeof y, typeof z);
// let o = {
//     "name": "prince",
//     "job role": 5600,
//     "is_hendsome":true
// }
// console.log(o);
// o.salary = "100cr";
// console.log(o);

