    // else if (realage == 0) {
    //     console.log("are you kidding");
    // }