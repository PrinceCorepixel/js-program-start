    let age = 18;
    // let grace = 2;
    // let realage = 0;


    // if ((age - grace) > 18) {
    //     console.log("You can vote");
    // }
    // else {
    //     console.log("You can not vote");
    // }
    if (age >= 18) {
        console.log("You can vote");
    }
    // else if (realage == 0) {
    //     console.log("are you kidding");
    // }
    // else if (realage == 18) {
    //     console.log("You  not vote");
    // }
    else {
        console.log("You can't cote");
    }